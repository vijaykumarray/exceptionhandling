package com.exceptionhandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionhandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
